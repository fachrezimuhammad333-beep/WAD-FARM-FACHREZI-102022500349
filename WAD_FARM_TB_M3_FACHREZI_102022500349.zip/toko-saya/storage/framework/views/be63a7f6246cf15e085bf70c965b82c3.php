<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data Mesin</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

<div class="container" style="max-width: 600px; margin: 30px auto;">
    <h2><?php echo e(isset($mesin) ? 'Edit Data Mesin' : 'Tambah Data Mesin'); ?></h2>

    <form action="<?php echo e(isset($mesin) ? route('mesin.update', $mesin->id) : route('mesin.store')); ?>"
          method="POST">

        <?php echo csrf_field(); ?>

        <?php if(isset($mesin)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <?php $__currentLoopData = [
            'nama_mesin' => 'Nama Mesin',
            'jenis_mesin' => 'Jenis Mesin',
            'merek' => 'Merek',
            'status' => 'Status'
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div style="margin-bottom: 15px;">
                <label for="<?php echo e($field); ?>"><?php echo e($label); ?></label>

                <input
                    type="text"
                    id="<?php echo e($field); ?>"
                    name="<?php echo e($field); ?>"
                    value="<?php echo e(old($field, isset($mesin) ? $mesin->$field : '')); ?>"
                    required
                    style="display: block; width: 100%; padding: 8px; box-sizing: border-box;"
                >

                <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small style="color: red;"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit">
            <?php echo e(isset($mesin) ? 'Perbarui Data' : 'Simpan Data'); ?>

        </button>

        <a href="<?php echo e(route('mesin.index')); ?>">Kembali</a>

    </form>
</div>

</body>
</html><?php /**PATH C:\laragon\www\toko-saya\resources\views/mesin/form.blade.php ENDPATH**/ ?>