<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mesin extends Model
{
    protected $table = 'mesins';

    protected $fillable = [
        'nama_mesin',
        'jenis_mesin',
        'merek',
        'status',
    ];
}