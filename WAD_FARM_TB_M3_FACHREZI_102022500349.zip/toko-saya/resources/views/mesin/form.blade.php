<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data Mesin</title>

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>

<div class="container" style="max-width: 600px; margin: 30px auto;">
    <h2>{{ isset($mesin) ? 'Edit Data Mesin' : 'Tambah Data Mesin' }}</h2>

    <form action="{{ isset($mesin) ? route('mesin.update', $mesin->id) : route('mesin.store') }}"
          method="POST">

        @csrf

        @if(isset($mesin))
            @method('PUT')
        @endif

        @foreach([
            'nama_mesin' => 'Nama Mesin',
            'jenis_mesin' => 'Jenis Mesin',
            'merek' => 'Merek',
            'status' => 'Status'
        ] as $field => $label)

            <div style="margin-bottom: 15px;">
                <label for="{{ $field }}">{{ $label }}</label>

                <input
                    type="text"
                    id="{{ $field }}"
                    name="{{ $field }}"
                    value="{{ old($field, isset($mesin) ? $mesin->$field : '') }}"
                    required
                    style="display: block; width: 100%; padding: 8px; box-sizing: border-box;"
                >

                @error($field)
                    <small style="color: red;">{{ $message }}</small>
                @enderror
            </div>

        @endforeach

        <button type="submit">
            {{ isset($mesin) ? 'Perbarui Data' : 'Simpan Data' }}
        </button>

        <a href="{{ route('mesin.index') }}">Kembali</a>

    </form>
</div>

</body>
</html>