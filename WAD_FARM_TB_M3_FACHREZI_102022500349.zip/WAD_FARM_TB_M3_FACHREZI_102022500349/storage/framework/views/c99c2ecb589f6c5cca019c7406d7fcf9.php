<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Mesin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<div class="container">
    <h1>Daftar Mesin Laundry</h1>
    <hr>
    <p>Tugas Modul Mesin &amp; Peralatan</p>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('mesin.create')); ?>" class="btn">+ Tambah Mesin</a>

    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Mesin</th>
                <th>Merek</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $mesin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($m->nama); ?></td>
                <td><?php echo e($m->merek); ?></td>
                <td><?php echo e($m->status); ?></td>
                <td>
                    <button type="button" class="btn btn-sm" data-bs-toggle="modal"
                            data-bs-target="#detail<?php echo e($m->id); ?>">Lihat Detail</button>
                    <a href="<?php echo e(route('mesin.edit', $m->id)); ?>" class="btn btn-sm">Edit</a>
                    <form action="<?php echo e(route('mesin.destroy', $m->id)); ?>" method="POST" class="d-inline"
                          onsubmit="return confirm('Yakin hapus data ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center">Belum ada data mesin.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

    <?php $__currentLoopData = $mesin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="detail<?php echo e($m->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header" style="background:#2f4858; color:#fff;">
                        <h5 class="modal-title"><?php echo e($m->nama); ?></h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p><b>Merek:</b> <?php echo e($m->merek); ?></p>
                        <p><b>Kapasitas:</b> <?php echo e($m->kapasitas); ?></p>
                        <p class="mb-0"><b>Kondisi:</b> <span class="text-success">● <?php echo e($m->status); ?></span></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\laundry-app\resources\views/mesin/index.blade.php ENDPATH**/ ?>